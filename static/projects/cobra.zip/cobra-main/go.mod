module github.com/spf13/cobra

go 1.15

require (
	github.com/cpuguy83/go-md2man/v2 v2.0.6
	github.com/inconshreveable/mousetrap v1.1.0
	github.com/spf13/pflag v1.0.9
	go.yaml.in/yaml/v3 v3.0.4
)
