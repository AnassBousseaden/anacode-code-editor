/*
 *
 *  Copyright 2017: Jan Sykora
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *
 */
package io.github.resilience4j.metrics;

import com.codahale.metrics.MetricRegistry;
import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadRegistry;

public class BulkheadMetricsTest extends AbstractBulkheadMetricsTest {

    @Override
    protected Bulkhead givenMetricRegistry(MetricRegistry metricRegistry) {
        BulkheadRegistry bulkheadRegistry = BulkheadRegistry.ofDefaults();
        Bulkhead bulkhead = bulkheadRegistry.bulkhead("testBulkhead");
        metricRegistry.registerAll(BulkheadMetrics.ofBulkhead(bulkhead));

        return bulkhead;
    }

    @Override
    protected Bulkhead givenMetricRegistry(String prefix, MetricRegistry metricRegistry) {
        BulkheadRegistry bulkheadRegistry = BulkheadRegistry.ofDefaults();
        Bulkhead bulkhead = bulkheadRegistry.bulkhead("testBulkhead");
        metricRegistry
            .registerAll(BulkheadMetrics.ofIterable(prefix, bulkheadRegistry.getAllBulkheads()));

        return bulkhead;
    }

}
